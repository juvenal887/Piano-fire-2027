package com.pianofire2027.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, lanes;
    TextView scoreView, comboView;
    int score=0, combo=0;
    Handler handler=new Handler();
    Random random=new Random();
    boolean playing=false;
    MediaPlayer music;

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float z,int c,boolean b){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);
        t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,b?1:0);return t;
    }
    GradientDrawable box(int c,float r){
        GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);splash();}
    @Override protected void onDestroy(){stopMusic();super.onDestroy();}

    void splash(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);
        root.setPadding(dp(20),dp(60),dp(20),dp(25));root.setBackgroundColor(Color.rgb(8,18,50));
        root.addView(tv("PIANO FIRE",48,Color.WHITE,true),new LinearLayout.LayoutParams(-1,dp(70)));
        root.addView(tv("2027",30,Color.rgb(255,80,210),true),new LinearLayout.LayoutParams(-1,dp(45)));
        root.addView(tv("EDM Music\n& New Rhythm",19,Color.WHITE,false),new LinearLayout.LayoutParams(-1,dp(70)));
        Space sp=new Space(this);root.addView(sp,new LinearLayout.LayoutParams(1,0,1));
        TextView p=tv("loading\n0%",20,Color.WHITE,true);root.addView(p,new LinearLayout.LayoutParams(dp(170),dp(170)));
        Space sp2=new Space(this);root.addView(sp2,new LinearLayout.LayoutParams(1,0,1));
        root.addView(tv("♬",42,Color.rgb(110,150,235),false),new LinearLayout.LayoutParams(-1,dp(50)));
        root.addView(tv("Nous recommandons l'utilisation d'un casque\npour une meilleure expérience de jeu.",16,Color.LTGRAY,false),new LinearLayout.LayoutParams(-1,dp(70)));
        setContentView(root);
        new Thread(()->{
            for(int i=0;i<=100;i++){int x=i;handler.post(()->p.setText("loading\n"+x+"%"));try{Thread.sleep(25);}catch(Exception e){}}
            handler.postDelayed(this::musicMenu,250);
        }).start();
    }

    void musicMenu(){
        root.removeAllViews();root.setPadding(dp(18),dp(25),dp(18),dp(20));root.setBackgroundColor(Color.rgb(5,10,31));
        root.addView(tv("PIANO FIRE 2027",30,Color.WHITE,true),new LinearLayout.LayoutParams(-1,dp(60)));
        root.addView(tv("CHOISIS TA MUSIQUE",19,Color.rgb(110,180,255),true),new LinearLayout.LayoutParams(-1,dp(45)));

        addTrack("🔥  Fire Night","Disponible dès l'ouverture",R.raw.fire_night,true);
        addTrack("🌌  Neon Dreams","Disponible dès l'ouverture",R.raw.neon_dreams,true);
        addTrack("☁️  Sky Rhythm","Disponible dès l'ouverture",R.raw.sky_rhythm,true);

        Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(15)));
        TextView more=tv("🔒  AUTRES MUSIQUES\nÀ TÉLÉCHARGER",18,Color.WHITE,true);
        more.setBackground(box(Color.rgb(35,48,95),22));
        more.setOnClickListener(v->downloadInfo());
        root.addView(more,new LinearLayout.LayoutParams(-1,dp(85)));

        root.addView(tv("3 musiques incluses • d'autres pourront être ajoutées par téléchargement",13,Color.LTGRAY,false),
                new LinearLayout.LayoutParams(-1,dp(55)));
    }

    void addTrack(String name,String info,int res,boolean free){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(7),dp(14),dp(7));card.setBackground(box(Color.rgb(18,28,65),20));
        TextView a=tv(name,18,Color.WHITE,true);card.addView(a,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView b=tv(info+"   ▶",13,Color.rgb(160,190,240),false);card.addView(b,new LinearLayout.LayoutParams(-1,dp(32)));
        card.setOnClickListener(v->{startMusic(res);game(name);});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(80));lp.setMargins(0,dp(6),0,dp(6));root.addView(card,lp);
    }

    void downloadInfo(){
        new AlertDialog.Builder(this).setTitle("Autres musiques")
            .setMessage("Cette section est prévue pour les morceaux supplémentaires. Ils pourront être téléchargés depuis une source que tu choisiras, puis ajoutés au jeu.")
            .setPositiveButton("OK",null).show();
    }

    void startMusic(int res){
        stopMusic();music=MediaPlayer.create(this,res);if(music!=null){music.setLooping(true);music.start();}
    }
    void stopMusic(){if(music!=null){try{music.stop();}catch(Exception e){}music.release();music=null;}}

    void game(String title){
        root.removeAllViews();root.setPadding(dp(14),dp(18),dp(14),dp(14));root.setBackgroundColor(Color.rgb(5,10,31));
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);
        scoreView=tv("SCORE 000000",16,Color.WHITE,true);comboView=tv("COMBO x0",16,Color.rgb(255,100,210),true);
        head.addView(scoreView,new LinearLayout.LayoutParams(0,dp(45),1));head.addView(comboView,new LinearLayout.LayoutParams(0,dp(45),1));root.addView(head);
        TextView titleView=tv("♫ "+title,17,Color.rgb(130,190,255),true);root.addView(titleView,new LinearLayout.LayoutParams(-1,dp(40)));
        lanes=new LinearLayout(this);lanes.setOrientation(LinearLayout.HORIZONTAL);lanes.setGravity(Gravity.BOTTOM);
        for(int i=0;i<4;i++){
            LinearLayout lane=new LinearLayout(this);lane.setOrientation(LinearLayout.VERTICAL);lane.setGravity(Gravity.BOTTOM);lane.setBackground(box(Color.rgb(15,22,54),8));
            final int laneNo=i;lane.setOnClickListener(v->hit(laneNo));
            lane.addView(tv(""+(i+1),15,Color.GRAY,true),new LinearLayout.LayoutParams(-1,dp(32)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,0,1);lp.setMargins(dp(3),0,dp(3),0);lanes.addView(lane,lp);
        }
        root.addView(lanes,new LinearLayout.LayoutParams(-1,0,1));
        TextView back=tv("← CHOISIR UNE AUTRE MUSIQUE",14,Color.LTGRAY,false);back.setOnClickListener(v->{stopMusic();musicMenu();});
        root.addView(back,new LinearLayout.LayoutParams(-1,dp(48)));
        playing=true;startNotes();
    }

    void hit(int lane){if(!playing)return;score+=100;combo++;scoreView.setText(String.format("SCORE %06d",score));comboView.setText("COMBO x"+combo);}
    void startNotes(){handler.postDelayed(new Runnable(){public void run(){if(!playing)return;spawnNote(random.nextInt(4));handler.postDelayed(this,650);}},400);}
    void spawnNote(int i){
        LinearLayout lane=(LinearLayout)lanes.getChildAt(i);TextView n=tv("●",30,Color.rgb(70,220,255),true);
        lane.addView(n,0,new LinearLayout.LayoutParams(-1,dp(42)));n.setBackground(box(Color.rgb(40,70,150),18));
        handler.postDelayed(()->{if(n.getParent()!=null){((ViewGroup)n.getParent()).removeView(n);combo=0;if(comboView!=null)comboView.setText("COMBO x0");}},1700);
    }
}
