# Piano Fire 2027 — compilation en ligne

Le dépôt contient un workflow GitHub Actions dans `.github/workflows/android.yml`.
Après import du projet dans un dépôt GitHub :
1. ouvrir l'onglet Actions ;
2. choisir "Build Piano Fire 2027 APK" ;
3. lancer "Run workflow" ;
4. attendre la fin du build ;
5. récupérer l'artifact `PianoFire2027-debug-apk`.

Cette compilation produit un APK de test (debug), pas une publication Play Store signée.
