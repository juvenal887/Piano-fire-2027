# Piano Fire 2027

Projet Android de démonstration comprenant :
- écran de démarrage PIANO FIRE 2027 avec chargement animé ;
- accueil sombre type jeu musical ;
- score et combo ;
- 4 grandes touches de piano interactives ;
- boutons de contrôle en bas.

Pour obtenir l'APK : ouvrir le projet dans Android Studio, synchroniser Gradle, puis
Build > Build APK(s).
